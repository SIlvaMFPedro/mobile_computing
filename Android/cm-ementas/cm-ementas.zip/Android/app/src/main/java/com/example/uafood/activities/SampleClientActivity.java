package com.example.uafood.activities;

// IMPORTS
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
public class SampleClientActivity {
}
